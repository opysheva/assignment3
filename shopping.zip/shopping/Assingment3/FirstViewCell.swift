import UIKit

class FirstViewCell: UITableViewCell {
    
    static let identifier = String(describing: FirstViewCell.self)
    static let nib = UINib(nibName: identifier, bundle: nil)
    
    @IBOutlet weak var firstImage: UIImageView!
    @IBOutlet weak var firstTitle: UILabel!
    @IBOutlet weak var firstDescr: UILabel!
    @IBOutlet weak var firstPrice: UILabel!
    
    
    
    var index: Int = 0
    var delegate: ViewControllerDelegate?

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    @IBAction func addToCartView (sender: Any) {
        delegate?.addToCartView (index)
    }
}
