import UIKit
protocol ViewControllerDelegate {
    func addToCartView(_ item: Int)
}

class ViewController: UIViewController {

    @IBOutlet var segmentControl: UIView!
    @IBOutlet weak var firstView: UITableView!
    @IBOutlet weak var secondView: UICollectionView!
    
    
    
    
    
    var a: [List] = []
    var b: [List] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.DataConfigure()
        firstView.isHidden = false
        secondView.isHidden = true
        
        firstView.delegate = self
        firstView.dataSource = self
        firstView.register(FirstViewCell.nib, forCellReuseIdentifier: FirstViewCell.identifier)
        
        self.secondView.dataSource = self
        self.secondView.delegate = self
        self.secondView.register(SecondViewCell.nib, forCellWithReuseIdentifier: SecondViewCell.indentifier)
    }
    
    @IBAction func switchTap(_ sender: Any) {
        
        if (firstView.isHidden){
            secondView.isHidden = true
            firstView.isHidden = false
        }
        else{
            firstView.isHidden = true
            secondView.isHidden = false
        }
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    
    private func DataConfigure(){
        self.a.append(List(image_item: "1", title: "LOUIS VUITTON", description: "BAG 006", price: 2450))
        self.a.append(List(image_item: "2", title: "CHANEL", description: "BAG 1145", price: 8000))
        self.a.append(List(image_item: "3", title: "YSL", description: "BAG LOCKME CHAIN", price: 5000))
        self.a.append(List(image_item: "4", title: "MICHAEL KORS", description: "BAG CLASSIC", price: 6500))
        self.a.append(List(image_item: "5", title: "BALENCIAGA", description: "BAG PM", price: 8600))
        self.a.append(List(image_item: "6", title: "BALENCIAGA", description: "BAG ONTHEGO MM", price: 1790))
    }
    
    @IBAction func cartTap(_ sender: Any) {
        guard let vc = storyboard?.instantiateViewController(identifier: CartViewController.identifier) as? CartViewController else{
                    return
            }
        vc.loved_items = self.b
        
        navigationController?.pushViewController(vc, animated: true)
    }
}


extension ViewController: ViewControllerDelegate{
    func addToCartView(_ item: Int) {
        let product = a[item]
        b.append(product)
    }
}


extension ViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.a.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: FirstViewCell.identifier, for: indexPath) as! FirstViewCell
        let close = self.a[indexPath.row]
        
        cell.firstTitle.text = close.title
        cell.firstDescr.text = close.description
        cell.firstImage.image = UIImage(named: close.image_item)
        cell.firstPrice.text = String(close.price)
        
        cell.index = indexPath.row
        cell.delegate = self
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let vc = storyboard?.instantiateViewController(identifier: InfoViewController.identifier) as? InfoViewController else{
                    return
            }
        tableView.deselectRow(at: indexPath, animated: true)
        vc.item = self.a[indexPath.row]
        vc.index = indexPath.row
        vc.delegate = self
        navigationController?.pushViewController(vc, animated: true)

    }
    

    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return CGFloat(150)
    }
}



extension ViewController :UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        
        self.a.count}
    
    
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = secondView.dequeueReusableCell(withReuseIdentifier: SecondViewCell.indentifier, for: indexPath) as! SecondViewCell
        let item = self.a[indexPath.item]
        cell.secondImage.image = UIImage(named: item.image_item)
        cell.secondTitle.text = item.title
        cell.secondDesc.text = item.description
        cell.secondPrice.text = String(item.price)
        cell.index = indexPath.row
        cell.delegate = self
        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let vc = storyboard?.instantiateViewController(identifier: InfoViewController.identifier) as? InfoViewController else{
                    return
            }
        
        
        
        
        secondView.deselectItem(at: indexPath, animated: true)
        vc.item = self.a[indexPath.row]
        vc.index = indexPath.row
        vc.delegate = self
        navigationController?.pushViewController(vc, animated: true)
    }
    
    
}

extension ViewController : UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = self.view.bounds.width/2
        return CGSize(width: width, height: 200)
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    
}
