import UIKit

class CartViewCell: UITableViewCell {
    
    static let identifier = String(describing: CartViewCell.self)
    static let nib = UINib(nibName: identifier, bundle: nil)
    
    @IBOutlet weak var cartTitle: UILabel!
    @IBOutlet weak var cartImage: UIImageView!
    @IBOutlet weak var cartDesc: UILabel!
    @IBOutlet weak var cartPrice: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
}
