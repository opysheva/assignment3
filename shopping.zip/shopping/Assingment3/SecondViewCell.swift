import UIKit

class SecondViewCell: UICollectionViewCell {
    
    @IBOutlet weak var secondImage: UIImageView!
    @IBOutlet weak var secondTitle: UILabel!
    @IBOutlet weak var secondDesc: UILabel!
    @IBOutlet weak var secondPrice: UILabel!
    
    static let indentifier = String(describing: SecondViewCell.self)
    static let nib = UINib(nibName: indentifier, bundle: nil)
    
    
    var index: Int = 0
    var delegate: ViewControllerDelegate?
    
    
    @IBAction func addCollection(_ sender: Any) {
           delegate?.addToCartView(index)
       }
       

    override func awakeFromNib() {
        super.awakeFromNib()
    }
   
}
