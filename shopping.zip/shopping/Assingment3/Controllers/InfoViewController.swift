import UIKit

class InfoViewController: UIViewController {
    
    
    @IBOutlet weak var infoImage: UIImageView!
    @IBOutlet weak var infoTitle: UILabel!
    @IBOutlet weak var infoDesc: UILabel!
    @IBOutlet weak var infoPrice: UILabel!
    
    
    
    static let identifier = String(describing: InfoViewController.self)

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = item!.title
        infoImage.image = UIImage(named: item!.image_item)
        infoDesc.text = item!.description
        infoTitle.text = item!.title
        infoPrice.text = String(item!.price)
    }
    override func viewWillAppear(_ animated: Bool) {
           navigationController?.setNavigationBarHidden(false, animated: animated)
       }
       
       
       @IBAction func AddButtonToCart(_ sender: Any) {
           delegate?.addToCartView(index)
       }
    
    public var item: List?
    var index: Int = 0
    var delegate: ViewControllerDelegate?
    
   }
