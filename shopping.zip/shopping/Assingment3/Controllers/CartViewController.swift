import UIKit

class CartViewController: UIViewController {
    
    var loved_items: [List] = []
    static let identifier = String(describing: CartViewController.self)
    
    
    @IBOutlet weak var cartTable: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = false
        cartTable.delegate = self
        cartTable.dataSource = self
        cartTable.register(CartViewCell.nib, forCellReuseIdentifier: CartViewCell.identifier)
    }
    
    
    @IBAction func buyButton(_ sender: Any) {
        let alert = UIAlertController(title: "Shopping", message: "Successfull", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: NSLocalizedString("SUCCESS", comment: "Default"), style: .default, handler: { _ in
        NSLog("The \"DONE\" ERROR")
            self.loved_items = []
            self.cartTable.reloadData()
        }))
        self.present(alert, animated: true, completion: nil)
    }
    
    
}

extension CartViewController :UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return loved_items.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return CGFloat(130)
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: CartViewCell.identifier, for: indexPath) as! CartViewCell
        let item = self.loved_items[indexPath.row]
        cell.cartImage.image = UIImage(named: item.image_item)
        cell.cartDesc.text = item.description
        cell.cartTitle.text = item.title
        cell.cartPrice.text = String(item.price)
        
        return cell
    }
    
    
}

    



