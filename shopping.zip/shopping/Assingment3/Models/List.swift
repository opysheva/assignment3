import Foundation

struct List {
    let image_item : String
    let title : String
    let description : String
    let price : Int
}
